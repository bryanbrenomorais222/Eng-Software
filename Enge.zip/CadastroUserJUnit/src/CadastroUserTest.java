import static org.junit.jupiter.api.Assertions.*;

import org.junit.Assert;
import org.junit.jupiter.api.Test;

public class CadastroUserTest {

	@Test
	public void testExecutaCadastro() {
		
		boolean b;
		
		b = CadastroUser.cadastroCompleto("d", "1");
		Assert.assertFalse(b);
		
	}
	

}
