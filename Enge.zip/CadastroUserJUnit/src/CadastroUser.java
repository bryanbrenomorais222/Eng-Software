

public class CadastroUser {
	
	String nome;
	String pass;
	
	public static boolean isEmpty (String nome, String pass) {
		if (nome == null && pass == null) {
			return true;
			
		}
		
		nome = nome.trim();
		return nome.length() ==0;
		
	}
	
	public static boolean cadastroCompleto(String nome, String pass) {
		if (nome == null && pass == null) {
			return false;
			
		}
		
		nome = nome.trim();
		return nome.length() == 0;
		
	}
	
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}


	
	
}
